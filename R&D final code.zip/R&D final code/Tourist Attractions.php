<?php
session_start();
$username = $_SESSION['username'] ?? false;
?>
<!DOCTYPE html>

<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">
		<title>NZTRI | Tourist Attractions</title>
		<style>
			.map{
				position:relative;
				left:120px;
				height: 300px;
				width: 500px;
			}

			#d1{
				position:relative;
				margin-right: 15%;
				width:300px;

			}

			img {
				margin-left: 5%;
			}
		</style>
		<link rel="stylesheet" href="./CSS/style.css">
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">

		</div>
		<nav>
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li class="current"><a href="Tourist Attractions.php">Attractions</a></li>
				<li><a href="Newsletter.php">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<li><a href="about.php">About</a></li>
				<?php
if($username)
						echo '<li><a href="logout.php">Logout</a></li>';
						else
		echo '<li><a href="Login.php">Login</a></li>';
?>
			</ul>
		</nav>
		</div>
		</header>

		<section id="main">
			<div class="container">
				<h2>Samoa</h2>

				<img src="./img/Samoa.jpg" alt="Samoa" width="550" height="300">
				<iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1937.1080545000889!2d-171.7581925904382!3d-13.826057897160648!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x71a5139f768ca707%3A0xdb98538a7aeeafc1!2sPalolo+Deep+Marine+Reserve!5e0!3m2!1sen!2snz!4v1557968946557!5m2!1sen!2snz" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<h4>Samoa is one of a beautiful place in the Pacific with their resorts, sandy beaches with unforgettable sunsets poolside bars, lush tropical gardens to wander through, sumptuous feasts and plenty of activities that you can either take part in, or simply relax and enjoy the charm of classic Samoan hospitality.</h4>

				<h2>Rarotonga</h2>
				<img src="./img/Rarotonga.jpg" alt="Rarotonga" width="550" height="300">
				<iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7436.672299776768!2d-159.73513040044932!3d-21.258157523268743!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x7157d388915ecd13%3A0x650471e4ac6e6ab4!2sMuri+Beach!5e0!3m2!1sen!2snz!4v1557969648344!5m2!1sen!2snz" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<h4>Rarotonga is a beautiful place for tourism for their vacations, they offer a BBQ, with some islands desert while you were arriving. The village will do some performances for the visitors involve some other dancing from other islands like Hawaii.</h4>

				<h2>Fiji</h2>
				<img src="./img/Fiji.jpg" alt="Fiji" width="550" height="300">
				<iframe class="map"src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d949.8563214346891!2d177.37945207725792!3d-17.77169878141244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6e1744cac1f1bfdf%3A0x31ade3194f7ca180!2sDenarau+Marina+Shopping+Centre%2C+Denarau+Island%2C+Fiji!5e0!3m2!1sen!2snz!4v1557969446756!5m2!1sen!2snz" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<h4>Warwick fiji - The Warwick Fiji is uniquely located on a stretch of brilliant gold sand beach with crystal clear lagoons on Fiji’s famed Coral Coast. </h4>

				<h2>Niue</h2>
				<img src="./img/Niue.jpg" alt="Niue" width="550" height="300">
				<iframe class="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60338.11487121782!2d-169.89754592463413!3d-19.05792522614511!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x719d252a376eb73b%3A0x914278347bdc8b18!2sNiue!5e0!3m2!1sen!2snz!4v1558192797640!5m2!1sen!2snz" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<h4>Scenic matavai resort - This magnificent resort is located on a clifftop with breathtaking 180-degree views of the blue Pacific Ocean and is only 10 minutes from all major facilities and services on Niue.</h4>
			</div>
		</section>

		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>
