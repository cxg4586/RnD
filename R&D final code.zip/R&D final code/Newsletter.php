<?php
session_start();
$username = $_SESSION['username'] ?? false;
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">

		<title>NZTRI | Newsletter</title>
		<link rel="stylesheet" href="./CSS/style.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
			integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<style>
			#main{
					min-height: calc(100vh - 200px);
			}

			.container{
					width: 80%;
					max-width: 80% !important;
			}

			footer{
				position: fixed;
					left: 0;
					bottom: 0;
					width: 100%;
					background-color:#e8491d;
					color: white;
				padding:20px;
				text-align:center;
			}

		</style>
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">

		</div>
		<nav>
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="Tourist Attractions.php">Attractions</a></li>
				<li class="current"><a href="Newsletter.php">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<li><a href="about.php">About</a></li>
				<?php
				if($username)
						echo '<li><a href="logout.php">Logout</a></li>';
						else
				echo '<li><a href="Login.php">Login</a></li>';
				?>
			</ul>
		</nav>
		</div>
		</header>
		<div class="container">
		<section id="main">
			<div class="shownews">
				<?php
								require_once 'settings.php';
								$username = $_SESSION['username'] ?? false;
								$isadmin = $_SESSION['isadmin'] ?? false;

								if($isadmin){
									//if user is admin, then can add/delete news
									echo "
									<html>
									<body>
											<div id='addnews'>
											<div class='col-md-11 col-sm-12'>
													<h1 class='mt-3'>Add News</h1>
													<form method=post action='addnews.php'>
														<div class='add_section'>
																<div class='form-group'>
																	<label><b>Topic Title:</b></label>
																	<input class='form-control' type='text' name='news_title' size=40 maxlength=150 index=1>
																</div>
																<div class='form-group'>
																	<label><b>News Text:</b></label>
																	<textarea class='form-control' type='text' name='news_text' rows=8 cols=40 wrap=virtual index=2></textarea>
																</div>
														</div>
														<div class='form-group mt-3'>
															<input class='btn btn-success' type='submit' name='submit' value='Add News'>
														</div>
													</form>
											</div>
											</div>
											</div>
											<script src='https://code.jquery.com/jquery-3.3.1.min.js'></script>
											<script>
											$('body').on('keydown', 'input', function(e) {
											var self = $(this)
											, form = self.parents('form:eq(0)')
											, focusable
											, next
											;
											if (e.keyCode == 13) {
												focusable = form.find('input,a,select,button,textarea').filter(':visible');
												next = focusable.eq(focusable.index(this)+1);
												if (next.length) {
													next.focus();
												} else {
													form.submit();
												}
												return false;
											}
										});
										</script>
									</body>
									</html>
									";
								}else if($username){
									//can only view news

								// }else{
								// 	header('Location: login.php');
								// 	exit();
								}
								require_once "shownews.php";
								?>
			</div>

		</section>
		</div>
		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>
