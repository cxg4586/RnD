<?php

require_once "settings.php";
session_start();
$id = $_GET['id'] ?? false;

$delete_query = "DELETE FROM `news` WHERE `news`.`news_id` = ".$id;
$result = mysqli_query($con, $delete_query) or die(mysqli_error($con));
if($result){
    echo "Delete successfully!";
    header("Location: Newsletter.php");
    exit();
}else{
    echo "Delete fail!";
}
?>


