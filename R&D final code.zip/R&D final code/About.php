<?php
session_start();
$username = $_SESSION['username'] ?? false;
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">

		<title>NZTRI | About</title>
		<link rel="stylesheet" href="./CSS/style.css">
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">

		</div>
		<nav>
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="Tourist Attractions.php">Attractions</a></li>
				<li><a href="Newsletter.php">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<li class="current"><a href="about.php">About</a></li>
				<?php
if($username)
						echo '<li><a href="logout.php">Logout</a></li>';
						else
		echo '<li><a href="Login.php">Login</a></li>';
?>
			</ul>
		</nav>
		</div>
		</header>

		<section id="main">
			<div class="container">
				<article id="main-col">
					<h1 class="page-title">About us</h1>
					<p>This online platform was created by five enthusiastic Bachelor of Computer Science students at the Auckand University<br/>
					of technology, who were interested with the tourism field. Our goal of this project is too help communities with little<br/>
					media exposure, gain more attraction by showing others places of interest for their destination. This project was sponsored<br/>
					by the help of the New Zealand Research Tourism Institute.</p>
					<img src="./img/43587002_272336766947692_8445707429831770112_n.jpg" width ="400" height="300" class="center">
					<h1>New Zealand Tourism Research Institute (NZTRI) </h1>
					<p>NZTRI is a company which is all about travel and tourism. It is an organisation that focuses on bringing timely and</br>
					   innovative research solutions for the tourism industry. Their main goal is to develop a sustainable and profitable </br>
					   tourism industry that gives citizens, organisations and visitors tangible benefits.</p>
					<p>AUT University</br>
					   Private Bag 92006</br>
					   Auckland 1142</br>
					   New Zealand</br>
					   nztri@aut.ac.nz</br>
					   +64 9 921 9999 extn 8890</br>
					   http://www.nztri.org</p>
				</article>
			</div>
		</section>

		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>
