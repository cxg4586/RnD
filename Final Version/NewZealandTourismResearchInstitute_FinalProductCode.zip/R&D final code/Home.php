<?php
session_start();
$username = $_SESSION['username'] ?? false;
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">

		<title>NZTRI | Welcome</title>
		<link rel="stylesheet" href="./CSS/style.css">
		<style>

		.heading{
			font-family: "Comic Sans MS", cursive, sans-serif;
		}


		* {box-sizing: border-box;}
		body {font-family: Verdana, sans-serif;}
		.mySlides {display: none;}
		img {vertical-align: middle;}

		/* Slideshow container */
		.slideshow-container {
		  max-width: 1000px;
		  position: relative;
		  margin: auto;
		}

		/* Caption text */
		.text {
		  color: #f2f2f2;
		  font-size: 15px;
		  padding: 8px 12px;
		  position: absolute;
		  bottom: 8px;
		  width: 100%;
		  text-align: center;
		}

		/* Number text (1/3 etc) */
		.numbertext {
		  color: #f2f2f2;
		  font-size: 12px;
		  padding: 8px 12px;
		  position: absolute;
		  top: 0;
		}

		/* The dots/bullets/indicators */
		.dot {
		  height: 15px;
		  width: 15px;
		  margin: 0 2px;
		  background-color: #bbb;
		  border-radius: 50%;
		  display: inline-block;
		  transition: background-color 0.6s ease;
		}

		.active {
		  background-color: #717171;
		}

		/* Fading animation */
		.fade {
		  -webkit-animation-name: fade;
		  -webkit-animation-duration: 1.5s;
		  animation-name: fade;
		  animation-duration: 1.5s;
		}

		@-webkit-keyframes fade {
		  from {opacity: .4}
		  to {opacity: 1}
		}

		@keyframes fade {
		  from {opacity: .4}
		  to {opacity: 1}
		}

		/* On smaller screens, decrease text size */
		@media only screen and (max-width: 300px) {
		  .text {font-size: 11px}
		}
		</style>
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">

		</div>
		<nav>
			<ul>
				<li class="current"><a href="Home.php">Home</a></li>
				<li><a href="Tourist Attractions.php">Attractions</a></li>
				<li><a href="Newsletter.php">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<li><a href="about.php">About</a></li>
                <?php
				if($username)
                    echo '<li><a href="logout.php">Logout</a></li>';
                    else
				    echo '<li><a href="Login.php">Login</a></li>';
				?>
			</ul>
		</nav>
		</div>
		</header>

		<!-- <section id="showcase">
			<div class="container">

			</div>
		</section> -->



		<section id="intro">
			<div class="int">
				<h1 class="heading"> Welcome to Paradise </h1>
				<p>Pacific Islands is a place like no other in the Pacific Ocean, is paradise and a perfect holiday destination. </br>
					This website will allow tourism to upload and share their destination's attraction to others.</p>
				<!-- <img src="./img/beach-coast-coastline-176395.jpg" width="600" height="400" class="center"> -->

				<!-- <div class="slideshow-container"> -->

				<div class="mySlides fade">
					<img src="./img/01.jpg" width="2000px" height="400px" class="center">
				</div>

				<div class="mySlides fade">
					<img src="./img/2.jpg" width="2000px" height="400px" class="center">
				</div>

				<div class="mySlides fade">
					<img src="./img/3.jpg" width="2000px" height="400px" class="center">
				</div>

				<!-- </div> -->
				<br>

				<div style="text-align:center">
				  <span class="dot"></span>
				  <span class="dot"></span>
				  <span class="dot"></span>
				</div>

				<script>
				var slideIndex = 0;
				showSlides();

				function showSlides() {
				  var i;
				  var slides = document.getElementsByClassName("mySlides");
				  var dots = document.getElementsByClassName("dot");
				  for (i = 0; i < slides.length; i++) {
				    slides[i].style.display = "none";
				  }
				  slideIndex++;
				  if (slideIndex > slides.length) {slideIndex = 1}
				  for (i = 0; i < dots.length; i++) {
				    dots[i].className = dots[i].className.replace(" active", "");
				  }
				  slides[slideIndex-1].style.display = "block";
				  dots[slideIndex-1].className += " active";
				  setTimeout(showSlides, 2000); // Change image every 2 seconds
				}
				</script>

			</div>
		</section>

		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>
