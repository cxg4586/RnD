

<?php
require_once "settings.php";
$sql = "SELECT * from news";
$result = $con->query($sql) ?? false;
?>


<html>
<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">

        <title>NZTRI | Tourist Attractions</title>
        <style>
body{
	font: 15px/1.5 Arial, Helvetica, sans-serif;
	padding:0;
	margin:0;
	background-color:#f4f4f4;
}

.container{
	width:80%;
	margin:auto;
	overflow:hidden;
}

ul{
	margin:0;
	padding:0;
}

#showcase{
	min-height: 400px;
	background:url('../img/beach-coast-coconut-trees-221471.jpg') no-repeat 0 -175px;
}

#intro h1{
	margin-top:100px;
	font-size:55px;
	margin-top:20px;
	text-align:center;
	color:#000;
}

#intro p{
	font-size:20px;
	text-align:center;
	color:#000;
	margin-top:-30px;
}

.center{
	display:block;
	margin-left:auto;
	margin-right:auto;
	width:50%;
}

footer{
	position: relative;
  	/* left: 0;
  	bottom: 0; */
  	width: 100%;
  	background-color:#e8491d;
  	color: white;
	padding:20px;
	text-align:center;
}

@media(max-width:768px){
	header #branding,
	header nav,
	header nav li,
	article#main-col{
		float:none;
		text-align:center;
		width:100%
	}

	header{
		padding-bottom:20px;
	}

	#intro h1{
		margin-top:40px;
	}
}
</style>
        <link rel="stylesheet" href="./CSS/style.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	</head>
	<body>
		<section id="main">
			<div class="container">
                <div class="row">
                    <div class="col-md-11 col-sm-12">
											<h1>Newsletter forum</h1>
											<table class="table">
													<thead>
													<tr>
															<th>Title</th>
															<th>Date & Time</th>
													</tr>
												</thead>
													<tbody>
                        <?php
												if($result){
													if ($result->num_rows > 0) {
                            // output data of each row
                            while ($row = $result->fetch_assoc()) {
                                echo "  <tr>
                                            <td><a href='news.php?id={$row['news_id']}'>{$row['news_title']}</a></td>
                                            <td>{$row['news_create_time']}</td>
											" . ($isadmin ? "<td><a class='btn btn-danger' href='deletenews.php?id={$row['news_id']}'><center>Delete</center></a></td>" : '') .
										"
								        </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>No news found</td></tr>";
                        }
												}
                        ?>



											</tbody>
										</table>

                        <br /><<b><a href="Home.php" class="">Go Back to the Home Page</a></b>
												
                    </div>
                </div>
            </div>
		</section>
	</body>

</html>
