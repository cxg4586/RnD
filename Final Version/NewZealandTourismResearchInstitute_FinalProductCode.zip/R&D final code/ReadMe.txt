The first file to open is the 'Home.php' file where you will be able to see all the remaining files through links.

When you click on the Registration Page ('registration.php') you must register and then login on the Login Page 
('login.php') in order to add posts on the discussion forum ('addtopic.php'). The admin is the only user that can 
edit content on the discussion forum.

The Admin Login details are:
Username: admin
password: adminpass

All the other pages are static pages.