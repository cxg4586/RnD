<?php

require_once 'settings.php';
$username = $_SESSION['username'] ?? false;
$isadmin = $_SESSION['isadmin'] ?? false;

//check for required fields from the form
if ( (!$_POST['news_title'])
    || (!$_POST['news_text'])) {
    // header('Location: Newsletter.php');
    // exit;
}

//create and issue the second query
$createAnotherQueryTable = "CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(191) DEFAULT NULL,
  `news_text` text,
  `news_create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;";

mysqli_query($con, $createAnotherQueryTable);
$text = mysqli_real_escape_string($con, nl2br($_POST['news_text']));
$add_news = "insert into news(news_title, news_text, news_create_time) values ('".$_POST['news_title']."',
'$text', now())";
mysqli_query($con, $add_news) or die(mysqli_error($con));

header('Location: news.php');
// header('Location: news.php?id='.$con->insert_id);

//create nice message for user
$msg = '<P>The <strong>$_news[topic_title]</strong> news has been created.</p>';
?>


