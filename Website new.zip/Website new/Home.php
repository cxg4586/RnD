<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">

		<title>NZTRI | Welcome</title>
		<link rel="stylesheet" href="./CSS/style.css">
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">

		</div>
		<nav>
			<ul>
				<li class="current"><a href="Home.php">Home</a></li>
				<li><a href="Tourist Attractions.html">Attractions</a></li>
				<li><a href="Newsletter.html">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<li><a href="about.html">About</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="Login.php">Login</a></li>
			</ul>
		</nav>
		</div>
		</header>

		<section id="showcase">
			<div class="container">

			</div>
		</section>

		<section id="intro">
			<div class="int">
				<h1> Tourism Website </h1>
				<p>This is a tourism website that allows users to upload and share their destination's attractions to others.<br/>
				The software is open source and can be regularly updated by the community.</p>
				<img src="./img/beach-coast-coastline-176395.jpg" width="600" height="400" class="center">
			</div>
		</section>

		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>
