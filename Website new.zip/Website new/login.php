<!DOCTYPE html>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    body {
        font-family: "Times New Roman", Times, serif;
    }

    * {
        box-sizing: border-box;
    }

    /* style the container */
    .container {
        position: relative;
        border-radius: 5px;
        background-color: beige;
        padding: 20px 0 30px 0;
    }

    /* style inputs and link buttons */
    input,
    .btn {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 4px;
        margin: 5px 0;
        opacity: 0.85;
        display: inline-block;
        font-size: 17px;
        line-height: 20px;
        text-decoration: none; /* remove underline from anchors */
    }

    input:hover,
    .btn:hover {
        opacity: 1;
    }

    /* add appropriate colors to fb, twitter and google buttons */
    .fb {
        background-color: #3B5998;
        color: white;
    }

    .twitter {
        background-color: #55ACEE;
        color: white;
    }

    .google {
        background-color: #dd4b39;
        color: white;
    }

    /* style the submit button */
    input[type=submit] {
        background-color: #4CAF50;
        color: white;
        cursor: pointer;
    }

    input[type=submit]:hover {
        background-color: #45a049;
    }

    /* Two-column layout */
    .col {
        float: left;
        width: 50%;
        margin: auto;
        padding: 0 50px;
        margin-top: 6px;
    }

    /* Clear floats after the columns */
    .row:after {
        content: "";
        display: table;
        clear: both;
    }

    /* vertical line */
    .vl {
        position: absolute;
        left: 50%;
        transform: translate(-50%);
        border: 2px solid #ddd;
        height: 175px;
    }

    /* text inside the vertical line */
    .vl-innertext {
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%);
        background-color: #f1f1f1;
        border: 1px solid #ccc;
        border-radius: 50%;
        padding: 8px 10px;
    }

    /* hide some text on medium and large screens */
    .hide-md-lg {
        display: none;
    }

    /* bottom container */
    .bottom-container {
        text-align: center;
        background-color: black;
        border-radius: 0px 0px 4px 4px;
    }

    /* Responsive layout - when the screen is less than 650px wide, make the two columns stack on top of each other instead of next to each other */
    @media screen and (max-width: 650px) {
        .col {
            width: 100%;
            margin-top: 0;
        }

        /* hide the vertical line */
        .vl {
            display: none;
        }

        /* show the hidden text on small screens */
        .hide-md-lg {
            display: block;
            text-align: center;
        }
    }

    div.btn {
        position: absolute;
        bottom: 5%;
        right: 0%;
    }
</style>

<html>
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php
require('settings.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['username'])) {
    // removes backslashes
    $username = stripslashes($_REQUEST['username']);
    //escapes special characters in a string
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);
    // for admin login
    if ($username === 'admin' && $password === 'adminpass') {
        $_SESSION['username'] = $username;
        $_SESSION['isadmin'] = true; // is admin loggedin
        // Redirect user to Home.php
        header("Location: Home.php");
    } else {
        //Checking is user existing in the database or not
        $query = "SELECT * FROM `userlist` WHERE username='$username'
and password='" . md5($password) . "'";
        $result = mysqli_query($con, $query) or die(mysqli_error($con));
        $rows = mysqli_num_rows($result);
        if ($rows > 0) {
            $_SESSION['username'] = $username;
            $_SESSION['isadmin'] = false; // not admin loggedin
            // Redirect user to Home.php
            header("Location: Home.php");
        } else {
            echo "<div class='form'>
<h3>Username/password is incorrect.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }

} else {
    ?>
    <div class="form">
        <h1>Log In</h1>
        <form action="" method="post" name="login">
            Username: <input type="text" name="username" placeholder="Username" required/><br/>
            Password: <input type="password" name="password" placeholder="Password" required/><br/>
            <input name="submit" type="submit" value="Login"/><br/>
        </form>
        <p>Not registered yet? <a href='register.php'>Register Here</a></p>
    </div>

    <div class="bottom-container">
        <div class="btn">
            <b>
                <a href="Home.php">
                    <button>Go Back to the Home Page</button>
                </a>
            </b>
        </div>
    </div>

<?php } ?>
</body>
</html>
