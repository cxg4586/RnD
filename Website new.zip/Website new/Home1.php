<!DOCTYPE html>

<?php
session_start();
$username = $_SESSION['username'] ?? false;
$isadmin = $_SESSION['isadmin'] ?? false;
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<style>
body{
	font: 15px/1.5 Arial, Helvetica, sans-serif;
	padding:0;
	margin:0;
	background-color:#f4f4f4;
}

.container{
	width:80%;
	margin:auto;
	overflow:hidden;
}

ul{
	margin:0;
	padding:0;
}

header{
	background:#1fbbe2;
	color:#ffffff;
	padding-top:30px;
	min-height:70px;
	border-bottom:#e8491d 3px solid;
}

header a{
	color:#ffffff;
	text-decoration:none;
	text-transform: uppercase;
	font-size: 16px;
}

header li{
	float: left;
	display:inline;
	padding: 0 20px 0 20px;
}

header #branding{
	float:left;
}

header #branding h1{
	margin:0;
}

header nav{
	float:right;
	margin-top:0px;
	padding: 0 0 10px 0;
}

header .highlight, header .current a{
	color:#e8491d;
	font-weight:bold;
}

header a:hover{
	color:#cccccc;
	font-weight:bold;
}

.row {
	position: absolute;
  	left: 75%;
  	top: 70px;
}
	
#showcase{
	min-height: 400px;
	background:url('../img/beach-coast-coconut-trees-221471.jpg') no-repeat 0 -175px;
}

#intro h1{
	margin-top:100px;
	font-size:55px;
	margin-top:20px;
	text-align:center;
	color:#000;
}

#intro p{
	font-size:20px;
	text-align:center;
	color:#000;
	margin-top:-10px;
}

.center{
	display:block;
	margin-left:auto;
	margin-right:auto;
	width:50%;
}

footer{
	padding:20px;
	margin-top:20px;
	color:#ffffff;
	background-color:#e8491d;
	text-align:center;
}

@media(max-width:768px){
	header #branding,
	header nav,
	header nav li,
	article#main-col{
		float:none;
		text-align:center;
		width:100%
	}
	
	header{
		padding-bottom:20px;
	}
	
	#intro h1{
		margin-top:40px;
	}
}
</style>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name = "viewport" content="width=device-width">
		
		<title>NZTRI | Welcome</title>
		<link rel="stylesheet" href="./CSS/style.css">
	</head>
	<body>
		<header>
		<div class = "container">
			<div id="branding">
			<img src="./img/nztri-logo-2016.png" alt="logo" width="300" height="100">
		</div>
		<nav>
			<ul>
				<li class="current"><a href="Home.php">Home</a></li>
        		<li><a href="About Us.html">About</a></li>
        		<li><a href="Tourist Attractions.html">Attractions</a></li>
        		<li><a href="register.php">Registration</a></li>
        		<li><a href="profile.php">Profile</a></li>
        		<li><a href="Newsletter.html">Newsletter</a></li>
				<li><a href="topics.php">Discussion</a></li>
				<?php
    				if ($username) {
        				echo '  <b><a href="#">' . ($isadmin ? 'Hi: ' : 'Hi: ') . $username . '! </a></b>
                				<b><a href="logout.php">Logout</a></b>';
    				} else {
        				echo '<b><a href="login.php">Login</a></b>';
    				}
    			?>
			</ul>
		</nav>
		<div class="row">
    	</div>
    		<div class="row">
        		<div class="right" style="background-color:#e9e9e9;">
            		<input type="text" id="mySearch" onkeyup="myFunction()" placeholder="Search.." title="Type in a category">
        		</div>
    		</div>
		</div>
		<script>
        	function myFunction() {
            	var input, filter, ul, li, a, i;
            	input = document.getElementById("mySearch");
            	filter = input.value.toUpperCase();
            	ul = document.getElementById("myMenu");
            	li = ul.getElementsByTagName("li");
            	for (i = 0; i < li.length; i++) {
                	a = li[i].getElementsByTagName("a")[0];
                	if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
                	    li[i].style.display = "";
                	} else {
                	    li[i].style.display = "none";
                	}
            	}
        	}
    	</script>
		</header>
		
		<section id="showcase">
			<div class="container">

			</div>
		</section>
		
		<section id="intro">
			<div class="int">
				<h1> Tourism Website </h1>
				<p>This is a tourism website that allows users to upload and share their destination's attractions to others.<br/>
				The software is open source and can be regularly updated by the community.</p>
				<img src="./img/beach-coast-coastline-176395.jpg" width="600" height="400" class="center">
			</div>
		</section>
		
		<footer>
			<p>NZTRI, Copyright &copy; 2019</p>
		</footer>
	</body>

</html>