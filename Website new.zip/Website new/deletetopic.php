<?php

require_once "settings.php";
session_start();
$id = $_GET['id'] ?? false;

$delete_query = "DELETE FROM `forum_posts` WHERE `forum_posts`.`post_id` = ".$id;
$result = mysqli_query($con, $delete_query) or die(mysqli_error($con));

if($result){
  echo "Delete successfully!";
  header("Location: topics.php");
  exit();
}else{
  echo "Delete fail!";
}
?>
