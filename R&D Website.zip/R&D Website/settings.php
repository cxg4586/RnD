<?php
// File for Requirements for Connection
$host = "cmslamp14.aut.ac.nz"; // Host Name
$user = ""; // Username
$pswd = ""; // Password
$dbnm = "register"; // Database Name
?>